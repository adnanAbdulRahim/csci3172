# Lab4

**[Optional]** If what is being submitted is an individual Lab or Assignment. Otherwise, include a brief one paragraph description about the project.
A website showcasing some of my random doodles

* *Date Created*: 1 Oct 2024
* *Last Modification Date*: 1 Oct 2024
* *Lab URL*: https://dal.brightspace.com/d2l/le/content/339466/viewContent/4472791/View


## Authors

If what is being submitted is an individual Lab or Assignment, you may simply include your name and email address. Otherwise list the members of your group.

* [Adnan](ad684424@dal.ca) - (Lead)

##Links

https://www.w3schools.com/js/js_regexp.asp for Regex

*Timberlea URL: https://web.cs.dal.ca/~abdulrahim/csci3172/lab4/
*Git URL: https://git.cs.dal.ca/abdulrahim/csci3172/-/tree/main/